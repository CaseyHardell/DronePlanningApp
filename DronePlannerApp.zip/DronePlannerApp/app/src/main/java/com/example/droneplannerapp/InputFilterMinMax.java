package com.example.droneplannerapp;

public class InputFilterMinMax{

    public boolean isInRange(double min, double max, double input) {
        return max > min && input >= min && input <= max;
    }

}