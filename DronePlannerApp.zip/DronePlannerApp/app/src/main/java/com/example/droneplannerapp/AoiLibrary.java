package com.example.droneplannerapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class AoiLibrary extends AppCompatActivity {
    ArrayAdapter arrayAdapter;
    ListView listView;
    DatabaseHelper db;
    String val;
    int index;
    boolean editMode;
    public static String aoiSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aoi_library);
        //Set the toolbar title
        Toolbar aoiLibraryToolbar = findViewById(R.id.aoiLibraryToolbar);
        //setSupportActionBar(aoiLibraryToolbar);
        aoiLibraryToolbar.setTitleTextColor(Color.WHITE);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.aoi_library_button);

        //Move to new aoi screen if the user presses the new aoi button
        Button addAoiBtn = findViewById(R.id.addAoiBtn);
        Intent activity_aoi_new = new Intent(getApplicationContext(), AoiNew.class);
        addAoiBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editMode = false;
                startActivity(activity_aoi_new);
            }
        });
        Button removeAoiBtn = findViewById(R.id.removeAoiBtn);
        removeAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //arrayAdapter.remove(arrayAdapter.getItem(arrayAdapter.getPosition(listView.getSelectedItem())));
                arrayAdapter.remove(val);
                db.deleteAOI(val);
                updateAdapter();
            }
        });
        Button editAoiBtn = findViewById(R.id.editAoiBtn);
        editAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMode = true;
                startActivity(activity_aoi_new);
            }
        });
        Button selectAoiBtn = findViewById(R.id.selectAoiBtn);
        Intent activity_specs_library = new Intent(getApplicationContext(), SpecsLibrary.class);
        selectAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aoiSelected = val;
                startActivity(activity_specs_library);
            }
        });
        //aoiNew aoiNew = new aoiNew();
        db = new DatabaseHelper(getApplicationContext());

        //Initialize AOI Library List View and show stored AOIs
        listView = findViewById(R.id.aoiListView);
        listView.setChoiceMode(listView.CHOICE_MODE_SINGLE);
        updateAdapter();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View v, int position,
                                    long arg3) {
                val = (String) adapter.getItemAtPosition(position);
                index = position;
                System.out.println(index);
            }
        });

    }

    //Update the ListView with added/edited/deleted rows
    public void updateAdapter() {
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.getAOINames());
        arrayAdapter.notifyDataSetChanged();
        listView.setAdapter(arrayAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAdapter();
    }

    public boolean editMode() {
        return editMode;
    }

}