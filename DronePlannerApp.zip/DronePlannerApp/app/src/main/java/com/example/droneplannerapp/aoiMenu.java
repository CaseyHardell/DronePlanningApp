package com.example.droneplannerapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

public class aoiMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aoimenu);

        //Create the screen title
        Toolbar aoiMenuToolbar = (Toolbar)findViewById(R.id.aoiMenuToolbar);
        setSupportActionBar(aoiMenuToolbar);
        getSupportActionBar().setTitle("AOI Menu");
    }
}