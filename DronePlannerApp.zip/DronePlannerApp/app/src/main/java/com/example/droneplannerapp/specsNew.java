package com.example.droneplannerapp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class specsNew extends AppCompatActivity {

    SPECS specs = new SPECS();
    public SpecsDatabaseHelper specsDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specs_new);

        specsDatabaseHelper = new SpecsDatabaseHelper(getApplicationContext());

        Toolbar mToolbar = findViewById(R.id.specsNewToolbar);
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("New Specs");
        }
        mToolbar.setTitleTextColor(Color.WHITE);

        EditText name = findViewById(R.id.editTextSpecsName);
        EditText gsd = findViewById(R.id.editTextSpecsGsd);
        EditText alt = findViewById(R.id.editTextSpecsAltitude);
        EditText frontOverlap = findViewById(R.id.editTextSpecsFrontOverlap);
        EditText sideOverlap = findViewById(R.id.editTextSpecsSideOverlap);
        EditText speed = findViewById(R.id.editTextSpecsSpeed);
        EditText maxBattery = findViewById(R.id.editTextSpecsMaxBatteryUse);
        EditText critBattery = findViewById(R.id.editTextSpecsCriticalBatteryUse);
        EditText precision = findViewById(R.id.editTextSpecsPrecision);
        EditText viewDistance = findViewById(R.id.editTextSpecsViewDistance);

        Button specsDoneBtn = findViewById(R.id.specsDoneBtn);
        specsDoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                specs.setSpecsName(name.getText().toString());
                specs.setSpecsGsd(Double.parseDouble(gsd.getText().toString()));
                specs.setSpecsAltitude(Double.parseDouble(alt.getText().toString()));
                specs.setSpecsFrontOverlap(Double.parseDouble(frontOverlap.getText().toString()));
                specs.setSpecsSideOverlap(Double.parseDouble(sideOverlap.getText().toString()));
                specs.setSpecsSpeed(Double.parseDouble(speed.getText().toString()));
                specs.setSpecsMaxBatteryUse(Double.parseDouble(maxBattery.getText().toString()));
                specs.setSpecsCriticalBatteryUse(Double.parseDouble(critBattery.getText().toString()));
                specs.setSpecsPrecision(Double.parseDouble(precision.getText().toString()));
                specs.setSpecsViewDistance(Double.parseDouble(viewDistance.getText().toString()));
                specsDatabaseHelper.createSpecsData(specs);
                finish();
            }
        });
    }
}
