package com.example.droneplannerapp;

public class SPECS {

    //Specs Name
    private String specsName;

    //Specs
    private int specsGsd;
    private int specsAltitude;
    private double specsFrontOverlap;
    private double specsSideOverlap;
    private int specsSpeed;
    private double specsMaxBatteryUse;
    private double specsCriticalBatteryUse;
    private int specsPrecision;
    private int specsViewDistance;

    public SPECS() {}

    //Set functions
    public void setSpecsName(String specsName) {this.specsName = specsName;}
    public void setSpecsGsd(int specsGsd){this.specsGsd = specsGsd;}
    public void setSpecsAltitude(int specsAltitude){this.specsAltitude = specsAltitude;}
    public void setSpecsFrontOverlap(double specsFrontOverlap){this.specsFrontOverlap = specsFrontOverlap;}
    public void setSpecsSideOverlap(double specsSideOverlap){this.specsSideOverlap = specsSideOverlap;}
    public void setSpecsSpeed(int specsSpeed){this.specsSpeed = specsSpeed;}
    public void setSpecsMaxBatteryUse(double specsMaxBatteryUse){this.specsMaxBatteryUse = specsMaxBatteryUse;}
    public void setSpecsCriticalBatteryUse(double specsCriticalBatteryUse){this.specsCriticalBatteryUse = specsCriticalBatteryUse;}
    public void setSpecsPrecision(int specsPrecision){this.specsPrecision = specsPrecision;}
    public void setSpecsViewDistance(int specsViewDistance){this.specsViewDistance = specsViewDistance;}

    //Get functions
    public String getSpecsName(){return this.specsName;}
    public int getSpecsGsd(){return this.specsGsd;}
    public int getSpecsAltitude(){return this.specsAltitude;}
    public double getSpecsFrontOverlap(){return this.specsFrontOverlap;}
    public double getSpecsSideOverlap(){return this.specsSideOverlap;}
    public int getSpecsSpeed(){return this.specsSpeed;}
    public double getSpecsMaxBatteryUse(){return this.specsMaxBatteryUse;}
    public double getSpecsCriticalBatteryUse(){return this.specsCriticalBatteryUse;}
    public int getSpecsPrecision(){return this.specsPrecision;}
    public int getSpecsViewDistance(){return this.specsViewDistance;}
}