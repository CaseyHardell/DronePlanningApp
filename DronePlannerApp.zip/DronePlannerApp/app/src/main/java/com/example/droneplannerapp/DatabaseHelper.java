package com.example.droneplannerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Log tag
    private static final String LOG = DatabaseHelper.class.getName();

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "Data";

    // Table Names
    private static final String TABLE_AOI = "AOI";

    //AOI Column Names
    private static final String KEY_AOIName = "Name";
    private static final String KEY_AOICoordinates = "Coordinates";

    // Create AOI Table
    private static final String CREATE_TABLE_AOI = "CREATE TABLE " + TABLE_AOI +
            "(" + KEY_AOIName + " TEXT PRIMARY KEY," + KEY_AOICoordinates + " TEXT" + ")";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_AOI);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    // Creating AOI
    public long createAOIData(AOI aoi) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        // Get Coordinates for AOI
        ArrayList<LatLng> coordinates = aoi.getCoordinates();

        // Initialize String
        StringBuilder coord_string = new StringBuilder();

        // Convert coordinate arraylist to string
        int i = 0;
        for (LatLng coordinate : coordinates) {
            if (i == 0) {
                coord_string = new StringBuilder(coordinate.latitude + " " + coordinate.longitude);
            } else {
                coord_string.append(", ").append(coordinate.latitude).append(" ").append(coordinate.longitude);
            }
            i++;
        }

        // Put Data to Values
        ContentValues values = new ContentValues();
        values.put(KEY_AOIName, aoi.getName());
        values.put(KEY_AOICoordinates, coord_string.toString());

        // insert row
        return sqLiteDatabase.insert(TABLE_AOI, null, values);
    }

    // Get All AOI Data
    public ArrayList<AOI> getAOIData() {
        ArrayList<AOI> aoiList = new ArrayList<>();
        ArrayList<LatLng> coords = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_AOI;

        Log.e(LOG, selectQuery);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                AOI aoi = new AOI();
                aoi.setName(c.getString(c.getColumnIndex(KEY_AOIName)));
                String coordinates = c.getString(c.getColumnIndex(KEY_AOICoordinates));
                String[] points = coordinates.split(",");
                int i = 0;
                for (String point : points) {
                    String[] point_data = point.split("\\s");
                    if (i == 0) {
                        coords.add(new LatLng(Double.parseDouble(point_data[0]), Double.parseDouble(point_data[1])));

                    } else {
                        coords.add(new LatLng(Double.parseDouble(point_data[1]), Double.parseDouble(point_data[2])));
                    }
                    i++;
                }
                aoi.setCoordinates(coords);

                // adding to list
                aoiList.add(aoi);
            } while (c.moveToNext());
        }
        c.close();

        return aoiList;
    }


    // Get All AOI Names
    public ArrayList<String> getAOINames() {
        ArrayList<String> aoiNames = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_AOI;

        Log.e(LOG, selectQuery);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                String name = c.getString(c.getColumnIndex(KEY_AOIName));

                // adding to list
                aoiNames.add(name);
            } while (c.moveToNext());
        }
        c.close();

        return aoiNames;
    }

    public void deleteAOI(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_AOI, KEY_AOIName + "=?", new String[]{name});
    }

}