package com.example.droneplannerapp;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class DroneNew extends AppCompatActivity {

    DRONE drone = new DRONE();
    InputFilterMinMax filter = new InputFilterMinMax();
    public DroneDatabaseHelper droneDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drone_new);

        droneDatabaseHelper = new DroneDatabaseHelper(getApplicationContext());

        Toolbar mToolbar = findViewById(R.id.droneNewToolbar);
        //setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("New Drone");
        }
        mToolbar.setTitleTextColor(Color.WHITE);

        EditText name = findViewById(R.id.editTextDroneName);
        EditText type = findViewById(R.id.editTextType);
        EditText maxFlightTime = findViewById(R.id.editTextMaxFlightTime);
        EditText maxSpeed = findViewById(R.id.editTextMaxSpeed);
        EditText focalLength = findViewById(R.id.editTextFocalLength);
        EditText sensorWidth = findViewById(R.id.editTextSensorWidth);
        EditText sensorHeight = findViewById(R.id.editTextSensorHeight);
        EditText imageWidth = findViewById(R.id.editTextImageWidth);
        EditText imageHeight = findViewById(R.id.editTextImageHeight);

        Button droneDoneBtn = findViewById(R.id.droneDoneBtn);
        droneDoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ensure that user entries are within bounds
                if(type.getText().toString().equals("Fixed-Wing") || type.getText().toString().equals("Multi-Rotor") && filter.isInRange(0,1000,Double.parseDouble(maxFlightTime.getText().toString()))
                        && filter.isInRange(0,100,Double.parseDouble(maxSpeed.getText().toString())) && filter.isInRange(0,100,Double.parseDouble(focalLength.getText().toString()))
                        && filter.isInRange(0,1000,Double.parseDouble(sensorWidth.getText().toString())) && filter.isInRange(0,100,Double.parseDouble(sensorHeight.getText().toString()))
                        && filter.isInRange(0,100,Double.parseDouble(imageWidth.getText().toString())) && filter.isInRange(0,1000,Double.parseDouble(imageHeight.getText().toString()))){
                    drone.setDroneName(name.getText().toString());
                    drone.setDroneType(type.getText().toString());
                    drone.setMaxFlightTime(Double.parseDouble(maxFlightTime.getText().toString()));
                    drone.setMaxSpeed(Double.parseDouble(maxSpeed.getText().toString()));
                    drone.setFocalLength(Double.parseDouble(focalLength.getText().toString()));
                    drone.setSensorWidth(Double.parseDouble(sensorWidth.getText().toString()));
                    drone.setSensorHeight(Double.parseDouble(sensorHeight.getText().toString()));
                    drone.setImageWidth(Double.parseDouble(imageWidth.getText().toString()));
                    drone.setImageHeight(Double.parseDouble(imageHeight.getText().toString()));
                    droneDatabaseHelper.createDroneData(drone);
                    finish();
                }else{
                    AlertDialog alertDialog = new AlertDialog.Builder(DroneNew.this).create();
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("One or more entries have violated the bounds");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }
        });
    }

}
