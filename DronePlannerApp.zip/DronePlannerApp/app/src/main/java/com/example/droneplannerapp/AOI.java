package com.example.droneplannerapp;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class AOI {

    // AOI name
    private String name;

    // List of coordinates for AOI boundary
    private ArrayList<LatLng> coordinates;

    public AOI() {}

    // Setters
    public void setName(String name) {this.name = name;}
    public void setCoordinates(ArrayList<LatLng> coordinates) {this.coordinates = coordinates;}

    // Getters
    public String getName() {return this.name;}
    public ArrayList<LatLng> getCoordinates() {return this.coordinates;}
}