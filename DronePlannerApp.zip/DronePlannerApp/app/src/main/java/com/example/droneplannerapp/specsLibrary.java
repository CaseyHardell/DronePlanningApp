package com.example.droneplannerapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class specsLibrary extends AppCompatActivity {

    ArrayAdapter arrayAdapter;
    ListView listView;
    SpecsDatabaseHelper db;
    String val;
    int index;
    boolean editMode;
    public static String specsSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specs_library);

        //Set the toolbar title
        Toolbar specsLibraryToolbar = findViewById(R.id.specsLibraryToolbar);
        setSupportActionBar(specsLibraryToolbar);
        specsLibraryToolbar.setTitleTextColor(Color.WHITE);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.specs_library_button);

        //Move to new specs screen if the user presses the new aoi button
        Button addAoiBtn = findViewById(R.id.addSpecsBtn);
        Intent activity_specs_new = new Intent(getApplicationContext(), specsNew.class);
        addAoiBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editMode = false;
                startActivity(activity_specs_new);
            }
        });
        Button removeAoiBtn = findViewById(R.id.removeSpecsBtn);
        removeAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //arrayAdapter.remove(arrayAdapter.getItem(arrayAdapter.getPosition(listView.getSelectedItem())));
                arrayAdapter.remove(val);
                db.deleteSpecs(val);
                updateAdapter();
            }
        });
        Button editAoiBtn = findViewById(R.id.editSpecsBtn);
        editAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMode = true;
                startActivity(activity_specs_new);
            }
        });
        Button selectAoiBtn = findViewById(R.id.selectSpecsBtn);
        Intent activity_specs_library = new Intent(getApplicationContext(), specsLibrary.class);
        selectAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                specsSelected = val;
                startActivity(activity_specs_library);
            }
        });
        Button removeSpecsBtn = findViewById(R.id.removeSpecsBtn);
        removeAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //arrayAdapter.remove(arrayAdapter.getItem(arrayAdapter.getPosition(listView.getSelectedItem())));
                arrayAdapter.remove(val);
                db.deleteSpecs(val);
                updateAdapter();
            }
        });
        Button editSpecsBtn = findViewById(R.id.editSpecsBtn);
        editAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMode = true;
                startActivity(activity_specs_new);
            }
        });
        Button selectSpecsBtn = findViewById(R.id.selectSpecsBtn);
        //Intent activity_specs_library = new Intent(getApplicationContext(), specsLibrary.class);
        selectAoiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //aoiSelected = val;
                //startActivity(activity_specs_library);
            }
        });

        db = new SpecsDatabaseHelper(getApplicationContext());

        //Initialize AOI Library List View and show stored AOIs
        listView = findViewById(R.id.specsListView);
        listView.setChoiceMode(listView.CHOICE_MODE_SINGLE);
        updateAdapter();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View v, int position,
                                    long arg3) {
                val = (String) adapter.getItemAtPosition(position);
                index = position;
                System.out.println(index);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAdapter();
    }

    //Update the ListView with added/edited/deleted rows
    public void updateAdapter() {
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.getSpecsNames());
        arrayAdapter.notifyDataSetChanged();
        listView.setAdapter(arrayAdapter);
    }
}