package com.example.droneplannerapp;

import android.app.Activity;

public class specsLibrary extends Activity {

}
