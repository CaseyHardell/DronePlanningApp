package com.example.droneplannerapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import java.util.Objects;

public class aoiLibrary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aoi_library);

        //Create the screen title
        Toolbar aoiLibraryToolbar = findViewById(R.id.aoiLibraryToolbar);
        setSupportActionBar(aoiLibraryToolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("AOI Library");
    }
}