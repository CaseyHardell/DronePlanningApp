package com.example.droneplannerapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class aoiLibrary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aoi_library);

        //Set the toolbar title
        Toolbar aoiLibraryToolbar = findViewById(R.id.aoiLibraryToolbar);
        setSupportActionBar(aoiLibraryToolbar);
        aoiLibraryToolbar.setTitleTextColor(Color.WHITE);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.aoi_library_button);

        //Move to new aoi screen if the user presses the new aoi button
        Button addAoiBtn = findViewById(R.id.addAoiBtn);
        Intent activity_aoi_new = new Intent(getApplicationContext(), aoiNew.class);
        addAoiBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(activity_aoi_new);
            }
        });
        //Initialize AOI Library List View
        ListView listView = findViewById(R.id.aoiListView);
    }

}