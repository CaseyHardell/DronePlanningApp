package com.example.droneplannerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SpecsDatabaseHelper extends SQLiteOpenHelper {

    //Log tag
    private static final String LOG = SpecsDatabaseHelper.class.getName();

    //Database Version
    private static final int DATABASE_VERSION  = 1;

    //Database Name
    private static final String DATABASE_NAME = "Specs Data";

    //Table Specs
    private static final String TABLE_SPECS = "Data";

    //Create Specs Table
    private static final String KEY_SPECSName = "Name";
    private static final int KEY_SPECSGsd = 0;
    private static final int KEY_SPECSAltitude = 0;
    private static final double KEY_SPECSFrontOverlap = 0;
    private static final double KEY_SPECSSideOverlap = 0;
    private static final int KEY_SPECSSpeed = 0;
    private static final double KEY_SPECSMaxBatteryUse = 0;
    private static final double KEY_SPECSCriticalBatteryUse = 0;
    private static final int KEY_SPECSPrecision = 0;
    private static final int KEY_SPECSViewDistance = 0;

    //Create Specs Table
    private static final String CREATE_TABLE_SPECS = "CREATE TABLE " + TABLE_SPECS + "(" + KEY_SPECSName + " TEXT PRIMARY KEY," + KEY_SPECSGsd + " INTEGER," +
            KEY_SPECSAltitude + " INTEGER," + KEY_SPECSFrontOverlap + " REAL," + KEY_SPECSSideOverlap + " REAL," + KEY_SPECSSpeed + " INTEGER, " + KEY_SPECSMaxBatteryUse +
            " REAL," + KEY_SPECSCriticalBatteryUse + " REAL," + KEY_SPECSPrecision + " INTEGER," + KEY_SPECSViewDistance + " INTEGER" + ")";

    public SpecsDatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SPECS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //Insert values into the specs database
    public long createSpecsData(SPECS specs){
        ContentValues values = new ContentValues();
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        //store database values
        values.put(KEY_SPECSName, specs.getSpecsName());
        values.put(String.valueOf(KEY_SPECSGsd), specs.getSpecsGsd());
        values.put(String.valueOf(KEY_SPECSAltitude), specs.getSpecsAltitude());
        values.put(String.valueOf(KEY_SPECSFrontOverlap), specs.getSpecsFrontOverlap());
        values.put(String.valueOf(KEY_SPECSSideOverlap), specs.getSpecsSideOverlap());
        values.put(String.valueOf(KEY_SPECSSpeed), specs.getSpecsSpeed());
        values.put(String.valueOf(KEY_SPECSMaxBatteryUse), specs.getSpecsMaxBatteryUse());
        values.put(String.valueOf(KEY_SPECSCriticalBatteryUse), specs.getSpecsCriticalBatteryUse());
        values.put(String.valueOf(KEY_SPECSPrecision), specs.getSpecsPrecision());
        values.put(String.valueOf(KEY_SPECSViewDistance), specs.getSpecsViewDistance());

        return sqLiteDatabase.insert(TABLE_SPECS, null, values);
    }
}