package com.example.droneplannerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DroneDatabaseHelper extends SQLiteOpenHelper {

    //Log tag
    private static final String LOG = DroneDatabaseHelper.class.getName();

    //Database Version
    private static final int DATABASE_VERSION  = 1;

    //Database Name
    private static final String DATABASE_NAME = "Drone_Data";

    //Table Specs
    private static final String TABLE_DRONE = "Drone_Data";

    //Create Specs Table
    private static final String KEY_DRONEName = "Name";
    private static final String KEY_DRONEType = "Type";
    private static final String KEY_DRONEMaxFlightTime = "Max_Flight_Time";
    private static final String KEY_DRONEMaxSpeed = "Max_Speed";
    private static final String KEY_DRONEFocalLength = "Focal_Length";
    private static final String KEY_DRONESensorWidth = "Sensor_Width";
    private static final String KEY_DRONESensorHeight = "Sensor_Height";
    private static final String KEY_DRONEImageWidth = "Image_Width";
    private static final String KEY_DRONEImageHeight = "Image_Height";

    //Create Specs Table
    private static final String CREATE_TABLE_DRONE = "CREATE TABLE " + TABLE_DRONE + "(" + KEY_DRONEName + " TEXT PRIMARY KEY," + KEY_DRONEType + " TEXT," +
            KEY_DRONEMaxFlightTime + " REAL," + KEY_DRONEMaxSpeed + " REAL," + KEY_DRONEFocalLength + " REAL," + KEY_DRONESensorWidth + " REAL," + KEY_DRONESensorHeight +
            " REAL," + KEY_DRONEImageWidth + " REAL," + KEY_DRONEImageHeight + " REAL" + ")";

    public DroneDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_DRONE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //Insert values into the specs database
    public long createDroneData(DRONE drone){
        ContentValues values = new ContentValues();
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        //store database values
        values.put(KEY_DRONEName, drone.getDroneName());
        values.put(KEY_DRONEType, drone.getDroneType());
        values.put(KEY_DRONEMaxFlightTime, drone.getMaxFlightTime());
        values.put(KEY_DRONEMaxSpeed, drone.getMaxSpeed());
        values.put(KEY_DRONEFocalLength, drone.getFocalLength());
        values.put(KEY_DRONESensorWidth, drone.getSensorWidth());
        values.put(KEY_DRONESensorHeight, drone.getSensorHeight());
        values.put(KEY_DRONEImageWidth, drone.getImageWidth());
        values.put(KEY_DRONEImageHeight, drone.getImageHeight());

        return sqLiteDatabase.insert(TABLE_DRONE, null, values);
    }

    // Get All AOI Names
    public ArrayList<String> getDroneNames() {
        ArrayList<String> droneNames = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_DRONE;

        Log.e(LOG, selectQuery);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                String name = c.getString(c.getColumnIndex(KEY_DRONEName));

                // adding to list
                droneNames.add(name);
            } while (c.moveToNext());
        }
        c.close();

        return droneNames;
    }

    public void deleteDrone(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_DRONE, KEY_DRONEName + "=?", new String[]{name});
    }
}