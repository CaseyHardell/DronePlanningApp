package com.example.droneplannerapp;

public class DRONE {

    //Drone Name
    private String droneName;

    //Drone
    private String droneType;
    private double maxFlightTime;
    private double maxSpeed;
    private double focalLength;
    private double sensorWidth;
    private double sensorHeight;
    private double imageWidth;
    private double imageHeight;

    public DRONE() {}

    //Set functions
    public void setDroneName(String droneName){this.droneName = droneName;}
    public void setDroneType(String droneType){this.droneType = droneType;}
    public void setMaxFlightTime(double maxFlightTime){this.maxFlightTime = maxFlightTime;}
    public void setMaxSpeed(double maxSpeed){this.maxSpeed = maxSpeed;}
    public void setFocalLength(double focalLength){this.focalLength = focalLength;}
    public void setSensorWidth(double sensorWidth){this.sensorWidth = sensorWidth;}
    public void setSensorHeight(double sensorHeight){this.sensorHeight = sensorHeight;}
    public void setImageWidth(double imageWidth){this.imageWidth = imageWidth;}
    public void setImageHeight(double imageHeight){this.imageHeight = imageHeight;}

    //Get functions
    public String getDroneName(){return this.droneName;}
    public String getDroneType(){return this.droneType;}
    public double getMaxFlightTime(){return this.maxFlightTime;}
    public double getMaxSpeed(){return this.maxSpeed;}
    public double getFocalLength(){return this.focalLength;}
    public double getSensorWidth(){return this.sensorWidth;}
    public double getSensorHeight(){return this.sensorHeight;}
    public double getImageWidth(){return this.imageWidth;}
    public double getImageHeight(){return this.imageHeight;}
}
