package com.example.droneplannerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class SpecsDatabaseHelper extends SQLiteOpenHelper {

    //Log tag
    private static final String LOG = SpecsDatabaseHelper.class.getName();

    //Database Version
    private static final int DATABASE_VERSION  = 1;

    //Database Name
    private static final String DATABASE_NAME = "Specs_Data";

    //Table Specs
    private static final String TABLE_SPECS = "Specs_Data";

    //Create Specs Table
    private static final String KEY_SPECSName = "Name";
    private static final String KEY_SPECSGsd = "GSD";
    private static final String KEY_SPECSAltitude = "Altitude";
    private static final String KEY_SPECSFrontOverlap = "Front_Overlap";
    private static final String KEY_SPECSSideOverlap = "Side_Overlap";
    private static final String KEY_SPECSSpeed = "Speed";
    private static final String KEY_SPECSMaxBatteryUse = "Max_Battery_Use";
    private static final String KEY_SPECSCriticalBatteryUse = "Critical_Battery_Use";
    private static final String KEY_SPECSPrecision = "Precision";
    private static final String KEY_SPECSViewDistance = "View_Distance";

    //Create Specs Table
    private static final String CREATE_TABLE_SPECS = "CREATE TABLE " + TABLE_SPECS + "(" + KEY_SPECSName + " TEXT PRIMARY KEY," + KEY_SPECSGsd + " REAL," +
            KEY_SPECSAltitude + " REAL," + KEY_SPECSFrontOverlap + " REAL," + KEY_SPECSSideOverlap + " REAL," + KEY_SPECSSpeed + " REAL," + KEY_SPECSMaxBatteryUse +
            " REAL," + KEY_SPECSCriticalBatteryUse + " REAL," + KEY_SPECSPrecision + " REAL," + KEY_SPECSViewDistance + " REAL" + ")";

    public SpecsDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SPECS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //Insert values into the specs database
    public long createSpecsData(SPECS specs){
        ContentValues values = new ContentValues();
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        //store database values
        values.put(KEY_SPECSName, specs.getSpecsName());
        values.put(KEY_SPECSGsd, specs.getSpecsGsd());
        values.put(KEY_SPECSAltitude, specs.getSpecsAltitude());
        values.put(KEY_SPECSFrontOverlap, specs.getSpecsFrontOverlap());
        values.put(KEY_SPECSSideOverlap, specs.getSpecsSideOverlap());
        values.put(KEY_SPECSSpeed, specs.getSpecsSpeed());
        values.put(KEY_SPECSMaxBatteryUse, specs.getSpecsMaxBatteryUse());
        values.put(KEY_SPECSCriticalBatteryUse, specs.getSpecsCriticalBatteryUse());
        values.put(KEY_SPECSPrecision, specs.getSpecsPrecision());
        values.put(KEY_SPECSViewDistance, specs.getSpecsViewDistance());

        return sqLiteDatabase.insert(TABLE_SPECS, null, values);
    }

    // Get All AOI Names
    public ArrayList<String> getSpecsNames() {
        ArrayList<String> specsNames = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_SPECS;

        Log.e(LOG, selectQuery);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                String name = c.getString(c.getColumnIndex(KEY_SPECSName));

                // adding to list
                specsNames.add(name);
            } while (c.moveToNext());
        }
        c.close();

        return specsNames;
    }

    public void deleteSpecs(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SPECS, KEY_SPECSName + "=?", new String[]{name});
    }
}