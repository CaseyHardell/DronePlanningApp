package com.example.droneplannerapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class SpecsLibrary extends AppCompatActivity {

    ArrayAdapter arrayAdapter;
    ListView listView;
    SpecsDatabaseHelper db;
    String val;
    int index;
    boolean editMode;
    public static String specsSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specs_library);

        //Set the toolbar title
        Toolbar specsLibraryToolbar = findViewById(R.id.specsLibraryToolbar);
        setSupportActionBar(specsLibraryToolbar);
        specsLibraryToolbar.setTitleTextColor(Color.WHITE);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.specs_library_button);

        //Move to new specs screen if the user presses the new aoi button
        Button addSpecsBtn = findViewById(R.id.addSpecsBtn);
        Intent activity_specs_new = new Intent(getApplicationContext(), SpecsNew.class);
        addSpecsBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editMode = false;
                startActivity(activity_specs_new);
            }
        });
        Button editSpecsBtn = findViewById(R.id.editSpecsBtn);
        editSpecsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMode = true;
                startActivity(activity_specs_new);
            }
        });
        Button selectSpecsBtn = findViewById(R.id.selectSpecsBtn);
        Intent activity_drone_library = new Intent(getApplicationContext(), DroneLibrary.class);
        selectSpecsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                specsSelected = val;
                startActivity(activity_drone_library);
            }
        });
        Button removeSpecsBtn = findViewById(R.id.removeSpecsBtn);
        removeSpecsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayAdapter.remove(val);
                db.deleteSpecs(val);
                updateAdapter();
            }
        });

        db = new SpecsDatabaseHelper(getApplicationContext());

        //Initialize AOI Library List View and show stored AOIs
        listView = findViewById(R.id.specsListView);
        listView.setChoiceMode(listView.CHOICE_MODE_SINGLE);
        updateAdapter();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View v, int position,
                                    long arg3) {
                val = (String) adapter.getItemAtPosition(position);
                index = position;
                System.out.println(index);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAdapter();
    }

    //Update the ListView with added/edited/deleted rows
    public void updateAdapter() {
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.getSpecsNames());
        arrayAdapter.notifyDataSetChanged();
        listView.setAdapter(arrayAdapter);
    }
}