package com.example.droneplannerapp;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class SpecsNew extends AppCompatActivity {

    SPECS specs = new SPECS();
    InputFilterMinMax filter = new InputFilterMinMax();
    public SpecsDatabaseHelper specsDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specs_new);

        specsDatabaseHelper = new SpecsDatabaseHelper(getApplicationContext());

        Toolbar mToolbar = findViewById(R.id.specsNewToolbar);
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("New Specs");
        }
        mToolbar.setTitleTextColor(Color.WHITE);

        EditText name = findViewById(R.id.editTextSpecsName);
        EditText gsd = findViewById(R.id.editTextSpecsGsd);
        EditText alt = findViewById(R.id.editTextSpecsAltitude);
        EditText frontOverlap = findViewById(R.id.editTextSpecsFrontOverlap);
        EditText sideOverlap = findViewById(R.id.editTextSpecsSideOverlap);
        EditText speed = findViewById(R.id.editTextSpecsSpeed);
        EditText maxBattery = findViewById(R.id.editTextSpecsMaxBatteryUse);
        EditText critBattery = findViewById(R.id.editTextSpecsCriticalBatteryUse);
        EditText precision = findViewById(R.id.editTextSpecsPrecision);
        EditText viewDistance = findViewById(R.id.editTextSpecsViewDistance);

        Button specsDoneBtn = findViewById(R.id.specsDoneBtn);
        specsDoneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ensure that user entries are within bounds
                boolean a = filter.isInRange(0,1000, Double.parseDouble(gsd.getText().toString()));
                System.out.println(a);
                if(filter.isInRange(0,1000, Double.parseDouble(gsd.getText().toString())) && filter.isInRange(0,1000,Double.parseDouble(alt.getText().toString()))
                && filter.isInRange(0,100,Double.parseDouble(frontOverlap.getText().toString())) && filter.isInRange(0,100,Double.parseDouble(sideOverlap.getText().toString()))
                && filter.isInRange(0,1000,Double.parseDouble(speed.getText().toString())) && filter.isInRange(0,100,Double.parseDouble(maxBattery.getText().toString()))
                && filter.isInRange(0,100,Double.parseDouble(critBattery.getText().toString())) && filter.isInRange(0,1000,Double.parseDouble(precision.getText().toString()))
                && filter.isInRange(0,100,Double.parseDouble(viewDistance.getText().toString()))){
                    specs.setSpecsName(name.getText().toString());
                    specs.setSpecsGsd(Double.parseDouble(gsd.getText().toString()));
                    specs.setSpecsAltitude(Double.parseDouble(alt.getText().toString()));
                    specs.setSpecsFrontOverlap(Double.parseDouble(frontOverlap.getText().toString())/100);
                    specs.setSpecsSideOverlap(Double.parseDouble(sideOverlap.getText().toString())/100);
                    specs.setSpecsSpeed(Double.parseDouble(speed.getText().toString()));
                    specs.setSpecsMaxBatteryUse(Double.parseDouble(maxBattery.getText().toString())/100);
                    specs.setSpecsCriticalBatteryUse(Double.parseDouble(critBattery.getText().toString())/100);
                    specs.setSpecsPrecision(Double.parseDouble(precision.getText().toString()));
                    specs.setSpecsViewDistance(Double.parseDouble(viewDistance.getText().toString()));
                    specsDatabaseHelper.createSpecsData(specs);
                    finish();
                }else{
                    AlertDialog alertDialog = new AlertDialog.Builder(SpecsNew.this).create();
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("One or more entries have violated the bounds");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

            }
        });
    }
}
