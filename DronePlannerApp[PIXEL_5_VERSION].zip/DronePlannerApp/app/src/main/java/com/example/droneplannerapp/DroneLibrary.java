package com.example.droneplannerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class DroneLibrary extends AppCompatActivity {

    ArrayAdapter arrayAdapter;
    ListView listView;
    DroneDatabaseHelper db;
    String val;
    int index;
    boolean editMode;
    public static String droneSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drone_library);

        //Set the toolbar title
        //Toolbar droneLibraryToolbar = findViewById(R.id.droneLibraryToolbar);
        //setSupportActionBar(droneLibraryToolbar);
        //droneLibraryToolbar.setTitleTextColor(Color.WHITE);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.drone_library_button);

        //Move to new drone screen if the user presses the new aoi button
        Button addDroneBtn = findViewById(R.id.addDroneBtn);
        Intent activity_drone_new = new Intent(getApplicationContext(), DroneNew.class);
        addDroneBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editMode = false;
                startActivity(activity_drone_new);
            }
        });
        Button editDroneBtn = findViewById(R.id.editDroneBtn);
        editDroneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editMode = true;
                startActivity(activity_drone_new);
            }
        });
        Button selectDroneBtn = findViewById(R.id.selectDroneBtn);
        Intent activity_drone_library = new Intent(getApplicationContext(), DroneLibrary.class);
        selectDroneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                droneSelected = val;
                startActivity(activity_drone_library);
            }
        });
        Button removeDroneBtn = findViewById(R.id.removeDroneBtn);
        removeDroneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //arrayAdapter.remove(arrayAdapter.getItem(arrayAdapter.getPosition(listView.getSelectedItem())));
                arrayAdapter.remove(val);
                db.deleteDrone(val);
                updateAdapter();
            }
        });

        db = new DroneDatabaseHelper(getApplicationContext());

        //Initialize AOI Library List View and show stored AOIs
        listView = findViewById(R.id.droneListView);
        listView.setChoiceMode(listView.CHOICE_MODE_SINGLE);
        updateAdapter();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View v, int position,
                                    long arg3) {
                val = (String) adapter.getItemAtPosition(position);
                index = position;
                //System.out.println(index);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAdapter();
    }

    //Update the ListView with added/edited/deleted rows
    public void updateAdapter() {
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, db.getDroneNames());
        arrayAdapter.notifyDataSetChanged();
        listView.setAdapter(arrayAdapter);
    }
}