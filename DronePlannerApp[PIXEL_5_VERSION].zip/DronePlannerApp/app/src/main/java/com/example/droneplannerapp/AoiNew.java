package com.example.droneplannerapp;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class AoiNew extends AppCompatActivity implements OnMapReadyCallback,
        LocationListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    private GoogleMap mMap;
    GoogleApiClient googleApiClient;

    LocationRequest locationRequest;
    Location currentLocation;
    String lastUpdateTime;
    int count = 0;
    int wp_count = 0;

    public DatabaseHelper db;

    public DatabaseHelper findDb(){return this.db;}

    private final static String TAG = AoiNew.class.getSimpleName();
    ArrayList<LatLng> coordList = new ArrayList();
    ArrayList<Polyline> polyline = new ArrayList<Polyline>();
    AOI aoi = new AOI();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aoi_new);

        //Toolbar mToolbar = findViewById(R.id.aoiNewToolbar);
        //setSupportActionBar(mToolbar);
        //if (getSupportActionBar() != null) {
        Objects.requireNonNull(getSupportActionBar()).setTitle("AOI New");
       // }
        //mToolbar.setTitleTextColor(Color.WHITE);

        db = new DatabaseHelper(getApplicationContext());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.aoiNewMap);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API).addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(AoiNew.this).build();
            googleApiClient.connect();
            locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(30 * 1000);
            locationRequest.setFastestInterval(5 * 1000);
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);

            // **************************
            builder.setAlwaysShow(true);
            // **************************

            PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi
                    .checkLocationSettings(googleApiClient, builder.build());
            result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
                @Override
                public void onResult(@NonNull LocationSettingsResult result) {
                    final Status status = result.getStatus();
                    switch (status.getStatusCode()) {
                        case LocationSettingsStatusCodes.SUCCESS:
                            // All location settings are satisfied. The client can
                            // initialize location
                            // requests here.
                            break;
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            // Location settings are not satisfied. But could be
                            // fixed by showing the user
                            // a dialog.
                            try {
                                // Show the dialog by calling
                                // startResolutionForResult(),
                                // and check the result in onActivityResult().
                                status.startResolutionForResult(AoiNew.this, 1000);
                            } catch (IntentSender.SendIntentException e) {
                                // Ignore the error.
                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            // Location settings are not satisfied. However, we have
                            // no way to fix the
                            // settings so we won't show the dialog.
                            break;
                    }
                }
            });
        }

        //Functionality for the done button
        Button doneBtn = findViewById(R.id.doneBtn);
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        final EditText input = new EditText(this);
        alertBuilder.setTitle(R.string.add_name_message);
        input.setInputType(InputType.TYPE_TEXT_VARIATION_NORMAL);
        input.setRawInputType(InputType.TYPE_TEXT_VARIATION_NORMAL);
        doneBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
            @Override
            public void onClick(View v) {
                alertBuilder.setView(input);
                alertBuilder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String name = input.getText().toString();
                        //Insert AOI into the database
                        aoi.setName(name);
                        aoi.setCoordinates(coordList);
                        db.createAOIData(aoi);
                        finish();
                    }
                });
                //Ensures the dismiss of the naming alert does not crash the app by using removeView on the EditText
                alertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        ((ViewGroup)input.getParent()).removeView(input);
                    }
                });
                //Display the naming alert
                alertBuilder.show();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            MarkerOptions markerOptions = new MarkerOptions();

            @Override
            public void onMapClick(final LatLng coords) {
                mMap.addMarker(new MarkerOptions().position(coords).draggable(true));
                coordList.add(coords);
                updatePolylines();
            }
        });

        mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            LatLng coord;
            int indexNum;

            @Override
            public void onMarkerDragStart(Marker marker) {
                //Get the starting coords before being dragged
                coord = marker.getPosition();
                //Get the index of the coord that is being dragged
                indexNum = coordList.indexOf(coord);
            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }

            //Update the value of the coordinate after it has been dropped
            @Override
            public void onMarkerDragEnd(Marker marker) {


                //Find the new coordinate
                coord = marker.getPosition();
                //Replace the old coordinate in the coordList with the new one
                coordList.set(indexNum, coord);
                updatePolylines();
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        googleApiClient.connect();
    }

    @Override
    public void onStop() {
        super.onStop();
        googleApiClient.disconnect();
    }

    @Override
    public void onBackPressed() {
        if (wp_count > 0) {
            // insert alert
            AlertDialog.Builder back = new AlertDialog.Builder(this);
            back.setTitle("Waypoints Not Saved")
                    .setMessage("Are you sure you would like to exit?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            //db.deleteCurrentMission();
                            AoiNew.this.finish();
                        }
                    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            AlertDialog alert = back.create();
            alert.show();

        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onDestroy() {
        //db.deleteCurrentMission();
        super.onDestroy();
//        if (started) {
//            stopLocationUpdates();
//        }
    }

    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (googleApiClient.isConnected()) {
            startLocationUpdates();
        }
        count = 0;
    }

    @Override
    public void onConnected(Bundle bundle) {
        startLocationUpdates();
        try {
            mMap.setMyLocationEnabled(true);
        } catch (SecurityException e) {
            Log.e(TAG, "Location Exception");
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        currentLocation = location;
        lastUpdateTime = DateFormat.getTimeInstance().format(new Date());
        if (count < 1) {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), 18));
        }
        count++;
        float accuracy = location.getAccuracy();
        //String full_gps_accuracy = gps_accuracy + " " + String.valueOf(accuracy) + "m";
        //GPSaccuracyTextView.setText(full_gps_accuracy);
    }

    protected void startLocationUpdates() {
        try {
            /*PendingResult<Status> pendingResult = LocationServices.FusedLocationApi
                    .requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);*/
            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);
            //started = true;
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestLocationPermissions();
            }
        }
    }

    // region Permissions
    @TargetApi(Build.VERSION_CODES.M)
    private void requestLocationPermissions() {
        // Android M Permission check
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("This app needs location access");
        builder.setMessage("Please grant location access so this app can use the GPS");
        builder.setPositiveButton(android.R.string.ok, null);
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        });
        builder.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            }
        }
    }

    public void updatePolylines() {
        //remove all polylines
        for (Polyline line : polyline) {
            line.remove();
        }
        polyline.clear();

        //redraw line between points
        for (int i = 0; i < coordList.size() - 1; i++) {
            polyline.add(mMap.addPolyline(new PolylineOptions().add(coordList.get(i), coordList.get(i + 1)).width(5).color(Color.RED)));
        }
        //draw a line from the last point to the first as long as there is more than one point
        if (coordList.size() >= 1) {
            polyline.add(mMap.addPolyline(new PolylineOptions().add(coordList.get(0), coordList.get(coordList.size() - 1)).width(5).color(Color.RED)));
        }
    }

    public DatabaseHelper getDb(){
        return db;
    }

}