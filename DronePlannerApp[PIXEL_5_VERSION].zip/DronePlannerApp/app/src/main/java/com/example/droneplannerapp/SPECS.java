package com.example.droneplannerapp;

public class SPECS {

    //Specs Name
    private String specsName;

    //Specs
    private double specsGsd;
    private double specsAltitude;
    private double specsFrontOverlap;
    private double specsSideOverlap;
    private double specsSpeed;
    private double specsMaxBatteryUse;
    private double specsCriticalBatteryUse;
    private double specsPrecision;
    private double specsViewDistance;

    public SPECS() {}

    //Set functions
    public void setSpecsName(String specsName) {this.specsName = specsName;}
    public void setSpecsGsd(double specsGsd){this.specsGsd = specsGsd;}
    public void setSpecsAltitude(double specsAltitude){this.specsAltitude = specsAltitude;}
    public void setSpecsFrontOverlap(double specsFrontOverlap){this.specsFrontOverlap = specsFrontOverlap;}
    public void setSpecsSideOverlap(double specsSideOverlap){this.specsSideOverlap = specsSideOverlap;}
    public void setSpecsSpeed(double specsSpeed){this.specsSpeed = specsSpeed;}
    public void setSpecsMaxBatteryUse(double specsMaxBatteryUse){this.specsMaxBatteryUse = specsMaxBatteryUse;}
    public void setSpecsCriticalBatteryUse(double specsCriticalBatteryUse){this.specsCriticalBatteryUse = specsCriticalBatteryUse;}
    public void setSpecsPrecision(double specsPrecision){this.specsPrecision = specsPrecision;}
    public void setSpecsViewDistance(double specsViewDistance){this.specsViewDistance = specsViewDistance;}

    //Get functions
    public String getSpecsName(){return this.specsName;}
    public double getSpecsGsd(){return this.specsGsd;}
    public double getSpecsAltitude(){return this.specsAltitude;}
    public double getSpecsFrontOverlap(){return this.specsFrontOverlap;}
    public double getSpecsSideOverlap(){return this.specsSideOverlap;}
    public double getSpecsSpeed(){return this.specsSpeed;}
    public double getSpecsMaxBatteryUse(){return this.specsMaxBatteryUse;}
    public double getSpecsCriticalBatteryUse(){return this.specsCriticalBatteryUse;}
    public double getSpecsPrecision(){return this.specsPrecision;}
    public double getSpecsViewDistance(){return this.specsViewDistance;}
}